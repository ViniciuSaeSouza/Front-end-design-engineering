let texto = document.querySelector('#idTexto')

texto.addEventListener('keydown', ()=>{
    let resultado = document.querySelector('#res')
    resultado.innerHTML = texto.value
})