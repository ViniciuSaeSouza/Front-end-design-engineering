export default function Compras(){

    return(
    <main className="flex p-10 justify-center">
      <h1 className="text-3xl font-bold text-indigo-800">Compras</h1>
    </main>
    )
}