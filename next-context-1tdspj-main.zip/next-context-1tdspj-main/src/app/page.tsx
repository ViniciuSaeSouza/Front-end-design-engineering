
export default function Home() {
  return (
    <main className="flex p-10 justify-center">
      <h1 className="text-3xl font-bold text-indigo-800">Home</h1>
    </main>
  );
}
