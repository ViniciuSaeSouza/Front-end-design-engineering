export default function Rodape(){

    return(
        <footer className="bg-indigo-950 p-5 flex justify-center items-center">
            <p className="text-white text-xl">Av. Paulista, 1060 - Bela Vista - São Paulo - SP</p>
        </footer>
    )
}

