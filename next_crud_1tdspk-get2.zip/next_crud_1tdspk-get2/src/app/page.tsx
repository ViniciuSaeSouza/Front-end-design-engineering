

export default function Home() {
  return (
    <main className="grow">
      <h1 className="text-center text-3xl mx-5">Home</h1>
    </main>
  );
}
